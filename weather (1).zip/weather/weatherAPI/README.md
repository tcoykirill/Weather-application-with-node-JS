# Weather App using NodeJS

This is a simple weather app built with Node.js that provides real-time weather information, a random image from Pexels, and a joke of the day.

## Features

- Get real-time weather information by providing the city, state code, and country code.
- Display temperature in both Fahrenheit and Celsius.
- Show additional weather details, including humidity, pressure, wind speed, and rain volume.
- View a map with the location marker based on the provided city.
- Display a random image from Pexels related to the provided city.
- Enjoy a joke of the day.

## Prerequisites

Before you begin, ensure you have the following:

- Node.js installed
- Pexels API key (sign up at [Pexels](https://www.pexels.com/api/))
- OpenWeatherMap API key (sign up at [OpenWeatherMap](https://openweathermap.org/api))
- OpenCage API key (sign up at [OpenCage Geocoding](https://opencagedata.com/api))
- JokeAPI key (sign up at [JokeAPI](https://jokeapi.dev/))

## Getting Started

1. How to start:

   ```bash 
   cd weatherAPI
   npm install
   
2. Keys:

        PEXELS_API_KEY=your-pexels-api-key
        OPENWEATHERMAP_API_KEY=your-openweathermap-api-key
        OPENCAGE_API_KEY=your-opencage-api-key
        JOKE_API_KEY=your-jokeapi-key

3.Start
```bash 
node server.js
