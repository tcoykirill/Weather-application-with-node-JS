
async function fetchJoke() {
    try {
        const jokeResponse = await fetch('https://sv443.net/jokeapi/v2/joke/Any');
        const jokeData = await jokeResponse.json();


        const setup = jokeData.setup || '';
        const delivery = jokeData.delivery || '';


        const jokeElement = document.querySelector('.joke');
        if (jokeElement) {
            jokeElement.innerHTML = `<p><strong>Joke of the Day:</strong> ${setup} ${delivery}</p>`;
        }
    } catch (error) {
        console.error('Error fetching joke:', error);
    }
}


window.onload = fetchJoke;