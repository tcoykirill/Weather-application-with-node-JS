const express = require("express");
const axios = require("axios");
const app = express();

// Set the view engine to EJS
app.set("view engine", "ejs");


app.use(express.static("public"));

// OpenWeatherMap API key
const apiKey = "2d76c4a5a3b5ac6903c696e43cf14223";
//  NASA API key
const nasaApiKey = "taIinGQpi4Jo2EouE9aphU13ukvhkfDy3SQSIA96";
//  OpenCage API key
const opencageApiKey = "467470be035046848314da5f854ee31c";
// JokeAPI key
const jokeApiKey = "sv443-joke-api"; //

app.get("/", (req, res) => {
  res.render("index", { weather: null, nasaImage: null, fictionalData: null, locationInfo: null, joke: null, error: null });
});

app.get("/weather", async (req, res) => {
  const city = req.query.city;
  const stateCode = req.query.stateCode;
  const countryCode = req.query.countryCode;
  const limit = 1;

  const geocodingAPI = `http://api.openweathermap.org/geo/1.0/direct?q=${city},${stateCode},${countryCode}&limit=${limit}&appid=${apiKey}`;

  try {
    const geoResponse = await axios.get(geocodingAPI);
    const { lat, lon } = geoResponse.data[0];

    const weatherAPI = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=imperial&appid=${apiKey}`;
    const weatherResponse = await axios.get(weatherAPI);
    const weather = weatherResponse.data;

    // data from NASA API
    const nasaAPI = `https://api.nasa.gov/planetary/apod?api_key=${nasaApiKey}`;
    const nasaResponse = await axios.get(nasaAPI);
    const nasaImage = nasaResponse.data.url;

    //  data from OpenCage Geocoding API
    const opencageAPI = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lon}&key=${opencageApiKey}`;
    const opencageResponse = await axios.get(opencageAPI);
    const locationInfo = opencageResponse.data.results[0].formatted;

    //  data from JokeAPI
    const jokeAPI = `https://sv443.net/jokeapi/v2/joke/${jokeApiKey}`;
    const jokeResponse = await axios.get(jokeAPI);
    const joke = jokeResponse.data;

    //  data from a fictional API
    const fictionalAPI = "https://jsonplaceholder.typicode.com/posts/1";
    const fictionalResponse = await axios.get(fictionalAPI);
    const fictionalData = {
      title: "City Characteristics",
      body: `Discover the enchanting city of ${city}, located in ${countryCode}. Known for its captivating landscapes, diverse culture, and friendly community, ${city} is a must-visit destination. Explore the unique blend of modern amenities and historic charm that defines this remarkable city.`
    };


    res.render("index", { weather, lat, lon, nasaImage, fictionalData, locationInfo, joke, error: null });
  } catch (error) {
    // Handle the error and provide default values for lat, lon, and additional data
    const defaultLat = 0;
    const defaultLon = 0;

    res.render("index", {
      weather: null,
      lat: defaultLat,
      lon: defaultLon,
      nasaImage: null,
      fictionalData: null,
      locationInfo: null,
      joke: null,
      error: "Error, Please try again"
    });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`App is running on port ${port} http://localhost:3000`);
});
